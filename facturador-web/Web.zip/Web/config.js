var SERVER_URL = "http://192.168.1.174:7220";
var RabbitWebSocket = "ws://192.168.1.174:15674/ws";
var ConvertirAFactura = false;
var ConvertirAOrden = false;
var GenerarFacturaelectronica = true;

